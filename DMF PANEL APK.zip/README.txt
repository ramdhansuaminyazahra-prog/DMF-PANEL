DMF PANEL - UI/flow repair build

Sudah diperbaiki:
- Flow Loading DMF -> video intro sampai selesai -> session -> Login/Home.
- UI dark gaming DMF biru/merah/hitam dibuat lebih rapi dan konsisten.
- Login, Register, Google, Facebook sudah punya layar/alur UI yang jelas.
- Home, role label, Quick Access, Pasang File, Buka Game, Logout.
- Panel DMF dengan master ON/OFF, sound, toggle state, Apply Preset, dan floating button in-app.
- State panel/toggle tidak langsung hilang karena refresh layar.

Belum diaktifkan sengaja:
- Firebase Auth Google/Facebook/email verification.
- Role server-side dan Developer Server.
- App Check / Play Integrity SHA-256.
Semua ini dilanjutkan setelah google-services.json dimasukkan dan APK punya signing certificate.

Catatan keamanan:
Panel saat ini hanya UI/preset aplikasi. Tidak ada cheat, inject, bypass anti-cheat, atau modifikasi memori game.
