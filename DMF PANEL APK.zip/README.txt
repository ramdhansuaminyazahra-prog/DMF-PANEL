DMF PANEL APK v0.6.0
- UI WEB PREVIEW 2 dipindah langsung ke APK via WebView agar visual konsisten.
- Firebase email/password login tetap native melalui bridge.
- Floating Panel Android asli memakai izin Display over other apps.
- Role awal ditampilkan FREE MEMBER. Role server-side belum diterapkan.
- Google/Facebook belum diaktifkan sampai provider Firebase dikonfigurasi.
- Floating tools saat ini UI/shortcut shell; tidak memodifikasi game.
