DMF PANEL - Starter v0.1
Flow: Loading -> Intro Video -> cek sesi login -> Login / Home.
Logo dan video intro user sudah dimasukkan.
Sudut UI dibuat rounded ringan, bukan kotak tajam.
CATATAN: Login v0.1 masih lokal untuk menguji flow UI. Google/Facebook/email verification dan role server-side akan disambungkan ke backend pada tahap berikutnya; jangan pakai login lokal ini untuk produksi.
