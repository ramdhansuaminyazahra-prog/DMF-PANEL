DMF PANEL WEB PREVIEW 2
Buka index.html. Setelah loading akan masuk Login. Tekan PREVIEW HOME untuk melihat Home. Tombol ☰ membuka menu samping. Tombol Floating Panel membuka simulasi panel mengambang. Ini preview UI; Firebase/social login belum dihubungkan.
