const $=s=>document.querySelector(s), $$=s=>document.querySelectorAll(s);
function show(id){$$('.screen').forEach(x=>x.classList.remove('active'));$(id).classList.add('active')}
setTimeout(()=>show('#login'),1600);
$$('[data-home]').forEach(b=>b.onclick=()=>show('#home'));
$$('[data-menu]').forEach(b=>b.onclick=()=>document.body.classList.add('drawerOpen'));
$$('[data-close]').forEach(b=>b.onclick=()=>document.body.classList.remove('drawerOpen'));
$$('[data-float]').forEach(b=>b.onclick=()=>{document.body.classList.remove('floatMini');document.body.classList.add('floatOpen')});
$('[data-min]').onclick=()=>{document.body.classList.remove('floatOpen');document.body.classList.add('floatMini')};
$('[data-fclose]').onclick=()=>{document.body.classList.remove('floatOpen','floatMini')};
let drag=false,ox=0,oy=0,box=$('#floating');
box.addEventListener('pointerdown',e=>{if(e.target.closest('button'))return;drag=true;ox=e.clientX-box.offsetLeft;oy=e.clientY-box.offsetTop;box.setPointerCapture(e.pointerId)});
box.addEventListener('pointermove',e=>{if(!drag)return;box.style.left=Math.max(0,Math.min(innerWidth-box.offsetWidth,e.clientX-ox))+'px';box.style.top=Math.max(0,Math.min(innerHeight-box.offsetHeight,e.clientY-oy))+'px';box.style.right='auto'});
box.addEventListener('pointerup',()=>drag=false);
// Android APK bridge
window.dmfLoginOk=function(name){ const n=document.querySelector('.who b'); if(n)n.childNodes[0].nodeValue=name+' '; show('#home'); };
const email=document.querySelector('#login input[placeholder="Email kamu"]');
const pass=document.querySelector('#login input[placeholder="Password kamu"]');
const loginBtn=document.querySelector('#login .primary');
if(loginBtn) loginBtn.onclick=()=>{ if(window.DMFNative) DMFNative.login(email.value,pass.value); else show('#home'); };
document.querySelectorAll('[data-float]').forEach(b=>b.onclick=()=>{ if(window.DMFNative) DMFNative.floatingPanel(); else {document.body.classList.remove('floatMini');document.body.classList.add('floatOpen')}});
const logout=document.querySelector('.logout'); if(logout) logout.onclick=()=>{ if(window.DMFNative) DMFNative.logout(); else location.reload(); };
