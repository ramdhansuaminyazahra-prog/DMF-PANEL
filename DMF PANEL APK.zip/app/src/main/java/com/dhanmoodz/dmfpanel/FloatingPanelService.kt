package com.dhanmoodz.dmfpanel

import android.app.Service
import android.content.Intent
import android.graphics.PixelFormat
import android.os.IBinder
import android.view.*
import android.widget.*
import android.graphics.Color
import android.graphics.drawable.GradientDrawable

class FloatingPanelService: Service() {
    private lateinit var wm: WindowManager
    private var view: View? = null
    override fun onBind(intent: Intent?): IBinder? = null
    override fun onStartCommand(intent: Intent?, flags:Int, startId:Int):Int { if(view==null) showPanel(); return START_NOT_STICKY }
    private fun bg(color:Int,r:Float,stroke:Int)=GradientDrawable().apply{setColor(color);cornerRadius=r;setStroke(2,stroke)}
    private fun showPanel(){
        wm=getSystemService(WINDOW_SERVICE) as WindowManager
        val root=LinearLayout(this).apply{orientation=LinearLayout.VERTICAL;setPadding(18,16,18,16);background=bg(Color.rgb(5,10,18),28f,Color.rgb(30,137,255))}
        val head=LinearLayout(this).apply{gravity=Gravity.CENTER_VERTICAL}
        val logo=ImageView(this).apply{setImageResource(R.drawable.dmf_logo);scaleType=ImageView.ScaleType.CENTER_CROP;background=bg(Color.BLACK,60f,Color.rgb(255,45,75));clipToOutline=true}
        head.addView(logo,LinearLayout.LayoutParams(62,62))
        head.addView(TextView(this).apply{text="  DMF PANEL\n  FLOATING TOOLS";setTextColor(Color.WHITE);textSize=13f},LinearLayout.LayoutParams(0,-2,1f))
        val close=Button(this).apply{text="×";setTextColor(Color.WHITE);background=bg(Color.rgb(35,8,16),14f,Color.rgb(255,45,75));setOnClickListener{stopSelf()}}
        head.addView(close,LinearLayout.LayoutParams(58,58));root.addView(head)
        val labels=listOf("Screenshot","Catatan","Browser","URL Tools","QR Code","AI Chat")
        labels.forEach{ s-> root.addView(Button(this).apply{text=s;setTextColor(Color.WHITE);textSize=12f;background=bg(Color.rgb(9,17,29),14f,Color.rgb(38,73,108))},LinearLayout.LayoutParams(-1,54).apply{topMargin=8}) }
        val type=WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY
        val lp=WindowManager.LayoutParams(330,-2,type,WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE,PixelFormat.TRANSLUCENT).apply{gravity=Gravity.TOP or Gravity.START;x=40;y=180}
        var sx=0;var sy=0;var tx=0f;var ty=0f
        head.setOnTouchListener{_,e->when(e.action){MotionEvent.ACTION_DOWN->{sx=lp.x;sy=lp.y;tx=e.rawX;ty=e.rawY;true};MotionEvent.ACTION_MOVE->{lp.x=sx+(e.rawX-tx).toInt();lp.y=sy+(e.rawY-ty).toInt();wm.updateViewLayout(root,lp);true};else->false}}
        view=root;wm.addView(root,lp)
    }
    override fun onDestroy(){view?.let{runCatching{wm.removeView(it)}};view=null;super.onDestroy()}
}
