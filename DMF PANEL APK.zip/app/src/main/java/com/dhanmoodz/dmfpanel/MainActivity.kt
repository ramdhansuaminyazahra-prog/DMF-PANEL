package com.dhanmoodz.dmfpanel

import android.app.*
import android.os.*
import android.graphics.Color
import android.media.MediaPlayer
import android.net.Uri
import android.text.InputType
import android.view.*
import android.widget.*
import android.graphics.drawable.GradientDrawable
import com.google.firebase.FirebaseApp
import com.google.firebase.appcheck.FirebaseAppCheck
import com.google.firebase.appcheck.playintegrity.PlayIntegrityAppCheckProviderFactory
import com.google.firebase.auth.FirebaseAuth

class MainActivity : Activity() {
    private val prefs by lazy { getSharedPreferences("dmf_session", MODE_PRIVATE) }
    private val auth by lazy { FirebaseAuth.getInstance() }
    private var panelActive = false

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        FirebaseApp.initializeApp(this)
        FirebaseAppCheck.getInstance().installAppCheckProviderFactory(
            PlayIntegrityAppCheckProviderFactory.getInstance()
        )
        showLoading()
    }

    private fun rounded(color:Int, radius:Float=28f, stroke:Int?=null)=GradientDrawable().apply {
        setColor(color); cornerRadius=radius; stroke?.let { setStroke(2,it) }
    }
    private fun base(): LinearLayout = LinearLayout(this).apply {
        orientation=LinearLayout.VERTICAL; gravity=Gravity.CENTER
        setPadding(48,48,48,48); setBackgroundColor(Color.rgb(5,7,11))
    }
    private fun text(s:String, size:Float=18f)=TextView(this).apply {
        text=s; textSize=size; setTextColor(Color.WHITE); gravity=Gravity.CENTER; setPadding(12,12,12,12)
    }
    private fun field(hintText:String, password:Boolean=false)=EditText(this).apply {
        hint=hintText; setTextColor(Color.WHITE); setHintTextColor(Color.GRAY)
        if(password) inputType=InputType.TYPE_CLASS_TEXT or InputType.TYPE_TEXT_VARIATION_PASSWORD
        background=rounded(Color.rgb(18,22,30),22f,Color.DKGRAY); setPadding(30,20,30,20)
    }
    private fun button(s:String, click:()->Unit)=Button(this).apply {
        text=s; setTextColor(Color.WHITE)
        background=rounded(Color.rgb(15,55,95),24f,Color.rgb(25,139,255))
        setOnClickListener{ click() }
    }
    private fun playSound(resId:Int) {
        val mp = MediaPlayer.create(this,resId) ?: return
        mp.setOnCompletionListener { it.release() }; mp.start()
    }
    private fun toast(s:String)=Toast.makeText(this,s,Toast.LENGTH_LONG).show()

    private fun showLoading(){
        val root=base()
        root.addView(ImageView(this).apply { setImageResource(R.drawable.dmf_logo); adjustViewBounds=true; layoutParams=LinearLayout.LayoutParams(430,430) })
        root.addView(text("DMF PANEL",30f)); root.addView(text("LOADING...",14f)); setContentView(root)
        Handler(Looper.getMainLooper()).postDelayed({ showIntro() },1800)
    }

    private fun showIntro(){
        val video=VideoView(this); setContentView(video)
        video.setVideoURI(Uri.parse("android.resource://$packageName/${R.raw.dmf_intro}"))
        video.setOnPreparedListener { it.isLooping=false; video.start() }
        video.setOnCompletionListener { routeAfterIntro() }
        video.setOnErrorListener { _,_,_-> routeAfterIntro(); true }
    }

    private fun routeAfterIntro(){
        val user=auth.currentUser
        if(user != null && user.isEmailVerified) showHome() else showLogin()
    }

    private fun showLogin(){
        val root=base(); root.addView(text("DMF PANEL",30f)); root.addView(text("LOGIN",20f))
        val email=field("Email")
        val pass=field("Password",true)
        root.addView(email, LinearLayout.LayoutParams(-1,-2).apply{setMargins(0,30,0,16)})
        root.addView(pass,LinearLayout.LayoutParams(-1,-2).apply{setMargins(0,0,0,24)})
        root.addView(button("LOGIN") {
            val e=email.text.toString().trim(); val p=pass.text.toString()
            if(e.isBlank() || p.isBlank()) { toast("Isi email dan password dulu"); return@button }
            auth.signInWithEmailAndPassword(e,p).addOnCompleteListener { task ->
                if(!task.isSuccessful) toast(task.exception?.localizedMessage ?: "Login gagal")
                else if(auth.currentUser?.isEmailVerified != true) { auth.signOut(); toast("Verifikasi email dulu, lalu login lagi") }
                else showHome()
            }
        },LinearLayout.LayoutParams(-1,-2))
        root.addView(button("REGISTER") { showRegister() },LinearLayout.LayoutParams(-1,-2).apply{setMargins(0,14,0,0)})
        root.addView(text("Google & Facebook akan diaktifkan setelah provider-nya dikonfigurasi di Firebase.",12f))
        setContentView(root)
    }

    private fun showRegister(){
        val root=base(); root.addView(text("DMF PANEL",30f)); root.addView(text("REGISTER",20f))
        val username=field("Username")
        val email=field("Email aktif")
        val pass=field("Password (min. 6 karakter)",true)
        listOf(username,email,pass).forEach { root.addView(it,LinearLayout.LayoutParams(-1,-2).apply{setMargins(0,12,0,0)}) }
        root.addView(button("BUAT AKUN") {
            val u=username.text.toString().trim(); val e=email.text.toString().trim(); val p=pass.text.toString()
            if(u.isBlank() || e.isBlank() || p.length<6) { toast("Isi username, email aktif, dan password minimal 6 karakter"); return@button }
            auth.createUserWithEmailAndPassword(e,p).addOnCompleteListener { task ->
                if(!task.isSuccessful) toast(task.exception?.localizedMessage ?: "Pendaftaran gagal")
                else {
                    prefs.edit().putString("username",u).apply()
                    auth.currentUser?.sendEmailVerification()?.addOnCompleteListener {
                        auth.signOut(); toast("Akun dibuat. Cek email verifikasi, lalu login."); showLogin()
                    }
                }
            }
        },LinearLayout.LayoutParams(-1,-2).apply{setMargins(0,22,0,0)})
        root.addView(button("KEMBALI KE LOGIN") { showLogin() },LinearLayout.LayoutParams(-1,-2).apply{setMargins(0,12,0,0)})
        setContentView(root)
    }

    private fun featureSwitch(label:String): Switch = Switch(this).apply {
        text=label; textSize=16f; setTextColor(Color.WHITE); setPadding(18,14,18,14)
        isEnabled = panelActive
        setOnCheckedChangeListener { _, _ -> playSound(R.raw.feature_toggle) }
    }

    private fun showHome(){
        val scroll=ScrollView(this); val root=base(); scroll.addView(root)
        val displayName=prefs.getString("username",null) ?: auth.currentUser?.email?.substringBefore("@") ?: "Member"
        root.addView(text("DMF PANEL",30f)); root.addView(text("Selamat datang, $displayName",17f)); root.addView(text("FREE MEMBER",14f))
        val status=text(if(panelActive) "PANEL AKTIF" else "PANEL NONAKTIF",16f); root.addView(status)
        val panelButton=button(if(panelActive) "MATIKAN PANEL" else "AKTIFKAN PANEL") {
            panelActive=!panelActive
            playSound(if(panelActive) R.raw.panel_on else R.raw.panel_off)
            showHome()
        }
        root.addView(panelButton,LinearLayout.LayoutParams(-1,-2).apply{setMargins(0,25,0,18)})
        root.addView(text("FITUR PANEL",18f))
        listOf("PRESET VISUAL", "FLOATING PANEL", "SOUND FEEDBACK", "QUICK SETTINGS").forEach { root.addView(featureSwitch(it),LinearLayout.LayoutParams(-1,-2)) }
        root.addView(text("Panel ini hanya mengatur fitur aplikasi DMF dan tidak memodifikasi game.",12f))
        root.addView(button("LOGOUT") { auth.signOut(); prefs.edit().clear().apply(); panelActive=false; showLogin() },LinearLayout.LayoutParams(-1,-2).apply{setMargins(0,24,0,0)})
        setContentView(scroll)
    }
}
