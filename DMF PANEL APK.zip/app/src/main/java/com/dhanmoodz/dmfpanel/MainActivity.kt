package com.dhanmoodz.dmfpanel

import android.app.Activity
import android.content.Intent
import android.net.Uri
import android.os.Bundle
import android.provider.Settings
import android.webkit.JavascriptInterface
import android.webkit.WebChromeClient
import android.webkit.WebView
import android.webkit.WebViewClient
import android.widget.Toast
import com.google.firebase.FirebaseApp
import com.google.firebase.auth.FirebaseAuth

class MainActivity : Activity() {
    private lateinit var web: WebView
    private val auth by lazy { FirebaseAuth.getInstance() }
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        FirebaseApp.initializeApp(this)
        web = WebView(this).apply {
            settings.javaScriptEnabled = true
            settings.domStorageEnabled = true
            settings.allowFileAccess = true
            webViewClient = WebViewClient()
            webChromeClient = WebChromeClient()
            addJavascriptInterface(Bridge(), "DMFNative")
            loadUrl("file:///android_asset/index.html")
        }
        setContentView(web)
    }
    override fun onBackPressed() {
        if (web.canGoBack()) web.goBack() else super.onBackPressed()
    }
    inner class Bridge {
        @JavascriptInterface fun login(email:String,password:String) = runOnUiThread {
            auth.signInWithEmailAndPassword(email.trim(), password).addOnCompleteListener { t ->
                if (t.isSuccessful) {
                    val u=auth.currentUser
                    if (u?.isEmailVerified == true) web.evaluateJavascript("window.dmfLoginOk && window.dmfLoginOk('${u.email?.substringBefore("@") ?: "Member"}')",null)
                    else { auth.signOut(); toast("Verifikasi email dulu") }
                } else toast(t.exception?.localizedMessage ?: "Login gagal")
            }
        }
        @JavascriptInterface fun register(username:String,email:String,password:String) = runOnUiThread {
            if(password.length<6){toast("Password minimal 6 karakter");return@runOnUiThread}
            auth.createUserWithEmailAndPassword(email.trim(),password).addOnCompleteListener { t ->
                if(t.isSuccessful){ getSharedPreferences("dmf_session",MODE_PRIVATE).edit().putString("username",username).apply(); auth.currentUser?.sendEmailVerification(); auth.signOut(); toast("Akun dibuat. Cek email verifikasi lalu login.") }
                else toast(t.exception?.localizedMessage ?: "Pendaftaran gagal")
            }
        }
        @JavascriptInterface fun logout() = runOnUiThread { auth.signOut(); web.evaluateJavascript("location.reload()",null) }
        @JavascriptInterface fun floatingPanel() = runOnUiThread {
            if (!Settings.canDrawOverlays(this@MainActivity)) {
                startActivity(Intent(Settings.ACTION_MANAGE_OVERLAY_PERMISSION, Uri.parse("package:$packageName")))
                toast("Izinkan DMF PANEL tampil di atas aplikasi lain, lalu tekan Floating Panel lagi")
            } else startService(Intent(this@MainActivity, FloatingPanelService::class.java))
        }
    }
    private fun toast(s:String)=Toast.makeText(this,s,Toast.LENGTH_LONG).show()
}
