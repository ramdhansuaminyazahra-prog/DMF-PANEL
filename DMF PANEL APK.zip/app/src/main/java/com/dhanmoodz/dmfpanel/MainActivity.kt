package com.dhanmoodz.dmfpanel

import android.app.Activity
import android.graphics.Color
import android.graphics.Matrix
import android.graphics.SurfaceTexture
import android.graphics.Typeface
import android.graphics.drawable.GradientDrawable
import android.media.MediaPlayer
import android.net.Uri
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.text.InputType
import android.view.Gravity
import android.view.Surface
import android.view.TextureView
import android.view.View
import android.view.ViewGroup
import android.view.WindowManager
import android.widget.*
import com.google.firebase.FirebaseApp
import com.google.firebase.appcheck.FirebaseAppCheck
import com.google.firebase.appcheck.playintegrity.PlayIntegrityAppCheckProviderFactory
import com.google.firebase.auth.FirebaseAuth

class MainActivity : Activity(), TextureView.SurfaceTextureListener {
    private val prefs by lazy { getSharedPreferences("dmf_session", MODE_PRIVATE) }
    private val auth by lazy { FirebaseAuth.getInstance() }
    private var panelActive = false
    private var introPlayer: MediaPlayer? = null
    private var introTexture: TextureView? = null

    private val bg = Color.rgb(3, 5, 10)
    private val panel = Color.rgb(10, 14, 23)
    private val panel2 = Color.rgb(15, 21, 33)
    private val blue = Color.rgb(28, 135, 255)
    private val red = Color.rgb(255, 55, 76)
    private val muted = Color.rgb(155, 166, 188)

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        window.setFlags(WindowManager.LayoutParams.FLAG_FULLSCREEN, WindowManager.LayoutParams.FLAG_FULLSCREEN)
        window.navigationBarColor = bg
        FirebaseApp.initializeApp(this)
        FirebaseAppCheck.getInstance().installAppCheckProviderFactory(
            PlayIntegrityAppCheckProviderFactory.getInstance()
        )
        showLoading()
    }

    override fun onDestroy() {
        introPlayer?.release()
        introPlayer = null
        super.onDestroy()
    }

    private fun dp(v: Int) = (v * resources.displayMetrics.density).toInt()

    private fun gradient(vararg colors: Int, radius: Float = 24f, strokeColor: Int? = null, strokeWidth: Int = 1): GradientDrawable =
        GradientDrawable(GradientDrawable.Orientation.TL_BR, colors).apply {
            cornerRadius = dp(radius.toInt()).toFloat()
            strokeColor?.let { setStroke(dp(strokeWidth), it) }
        }

    private fun solid(color: Int, radius: Int = 20, strokeColor: Int? = null): GradientDrawable =
        GradientDrawable().apply {
            setColor(color)
            cornerRadius = dp(radius).toFloat()
            strokeColor?.let { setStroke(dp(1), it) }
        }

    private fun rootFrame(): FrameLayout = FrameLayout(this).apply {
        background = gradient(Color.rgb(2, 4, 9), Color.rgb(5, 8, 16), Color.rgb(3, 5, 10), radius = 0f)
    }

    private fun title(text: String, size: Float = 26f): TextView = TextView(this).apply {
        this.text = text
        textSize = size
        setTextColor(Color.WHITE)
        gravity = Gravity.CENTER
        typeface = Typeface.create("sans-serif-condensed", Typeface.BOLD)
        letterSpacing = .06f
    }

    private fun sub(text: String, size: Float = 13f): TextView = TextView(this).apply {
        this.text = text
        textSize = size
        setTextColor(muted)
        gravity = Gravity.CENTER
        typeface = Typeface.create("sans-serif", Typeface.NORMAL)
    }

    private fun neonLine(color: Int): View = View(this).apply {
        background = gradient(Color.TRANSPARENT, color, Color.TRANSPARENT, radius = 0f)
    }

    private fun field(hintText: String, password: Boolean = false): EditText = EditText(this).apply {
        hint = hintText
        textSize = 15f
        setTextColor(Color.WHITE)
        setHintTextColor(Color.rgb(115, 128, 151))
        setPadding(dp(18), dp(14), dp(18), dp(14))
        background = solid(panel2, 16, Color.rgb(47, 62, 88))
        if (password) inputType = InputType.TYPE_CLASS_TEXT or InputType.TYPE_TEXT_VARIATION_PASSWORD
    }

    private fun neonButton(label: String, primary: Boolean = true, click: () -> Unit): TextView = TextView(this).apply {
        text = label
        textSize = 14f
        gravity = Gravity.CENTER
        typeface = Typeface.DEFAULT_BOLD
        setTextColor(Color.WHITE)
        setPadding(dp(18), dp(14), dp(18), dp(14))
        background = if (primary) gradient(Color.rgb(15, 84, 170), Color.rgb(115, 31, 70), radius = 16f, strokeColor = blue)
        else solid(Color.rgb(12, 17, 27), 16, Color.rgb(55, 68, 93))
        isClickable = true
        isFocusable = true
        setOnClickListener {
            animate().scaleX(.97f).scaleY(.97f).setDuration(70).withEndAction {
                animate().scaleX(1f).scaleY(1f).setDuration(90).start()
                click()
            }.start()
        }
    }

    private fun card(): LinearLayout = LinearLayout(this).apply {
        orientation = LinearLayout.VERTICAL
        gravity = Gravity.CENTER_HORIZONTAL
        setPadding(dp(22), dp(22), dp(22), dp(22))
        background = gradient(Color.rgb(10, 15, 26), Color.rgb(9, 11, 18), radius = 24f, strokeColor = Color.rgb(43, 92, 150))
        elevation = dp(8).toFloat()
    }

    private fun logo(sizeDp: Int): ImageView = ImageView(this).apply {
        setImageResource(R.drawable.dmf_logo)
        scaleType = ImageView.ScaleType.FIT_CENTER
        adjustViewBounds = true
        background = Color.TRANSPARENT.toDrawableCompat()
        elevation = dp(2).toFloat()
        layoutParams = LinearLayout.LayoutParams(dp(sizeDp), dp(sizeDp))
    }

    private fun Int.toDrawableCompat(): android.graphics.drawable.ColorDrawable =
        android.graphics.drawable.ColorDrawable(this)

    private fun playSound(resId: Int) {
        val mp = MediaPlayer.create(this, resId) ?: return
        mp.setOnCompletionListener { it.release() }
        mp.start()
    }

    private fun toast(s: String) = Toast.makeText(this, s, Toast.LENGTH_LONG).show()

    private fun showLoading() {
        val root = rootFrame()
        val stack = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            gravity = Gravity.CENTER
            setPadding(dp(28), dp(28), dp(28), dp(28))
        }
        root.addView(stack, FrameLayout.LayoutParams(-1, -1))

        val topLine = neonLine(blue)
        stack.addView(topLine, LinearLayout.LayoutParams(dp(240), dp(2)).apply { bottomMargin = dp(28) })
        stack.addView(logo(190))
        stack.addView(title("DMF PANEL", 31f), LinearLayout.LayoutParams(-1, -2).apply { topMargin = dp(26) })
        stack.addView(sub("DHAN MOODZ OFFICIAL", 12f), LinearLayout.LayoutParams(-1, -2).apply { topMargin = dp(3) })

        val pill = TextView(this).apply {
            text = "INITIALIZING SECURE SESSION"
            textSize = 11f
            gravity = Gravity.CENTER
            typeface = Typeface.DEFAULT_BOLD
            setTextColor(Color.rgb(193, 213, 241))
            setPadding(dp(18), dp(10), dp(18), dp(10))
            background = solid(Color.rgb(10, 20, 34), 99, Color.rgb(41, 91, 153))
        }
        stack.addView(pill, LinearLayout.LayoutParams(-2, -2).apply { topMargin = dp(20) })

        val bar = ProgressBar(this, null, android.R.attr.progressBarStyleHorizontal).apply {
            isIndeterminate = true
            indeterminateTintList = android.content.res.ColorStateList.valueOf(blue)
        }
        stack.addView(bar, LinearLayout.LayoutParams(dp(245), dp(6)).apply { topMargin = dp(24) })

        val bottomLine = neonLine(red)
        stack.addView(bottomLine, LinearLayout.LayoutParams(dp(180), dp(2)).apply { topMargin = dp(28) })

        setContentView(root)
        Handler(Looper.getMainLooper()).postDelayed({ showIntro() }, 1500)
    }

    private fun showIntro() {
        introPlayer?.release()
        val root = FrameLayout(this).apply { setBackgroundColor(Color.BLACK) }
        val texture = TextureView(this).apply {
            surfaceTextureListener = this@MainActivity
        }
        introTexture = texture
        root.addView(texture, FrameLayout.LayoutParams(-1, -1))

        val badge = TextView(this).apply {
            text = "DMF"
            setTextColor(Color.WHITE)
            textSize = 11f
            typeface = Typeface.DEFAULT_BOLD
            gravity = Gravity.CENTER
            background = solid(Color.argb(145, 8, 13, 23), 99, Color.argb(185, 48, 133, 255))
            setPadding(dp(12), dp(6), dp(12), dp(6))
        }
        root.addView(badge, FrameLayout.LayoutParams(-2, -2, Gravity.TOP or Gravity.END).apply {
            topMargin = dp(16); rightMargin = dp(16)
        })
        setContentView(root)
    }

    override fun onSurfaceTextureAvailable(surfaceTexture: SurfaceTexture, width: Int, height: Int) {
        val surface = Surface(surfaceTexture)
        introPlayer = MediaPlayer().apply {
            setDataSource(this@MainActivity, Uri.parse("android.resource://$packageName/${R.raw.dmf_intro}"))
            setSurface(surface)
            isLooping = false
            setOnPreparedListener { mp ->
                applyCenterCrop(mp.videoWidth, mp.videoHeight, width, height)
                mp.start()
            }
            setOnVideoSizeChangedListener { _, vw, vh -> applyCenterCrop(vw, vh, introTexture?.width ?: width, introTexture?.height ?: height) }
            setOnCompletionListener { routeAfterIntro() }
            setOnErrorListener { _, _, _ -> routeAfterIntro(); true }
            prepareAsync()
        }
    }

    private fun applyCenterCrop(videoW: Int, videoH: Int, viewW: Int, viewH: Int) {
        if (videoW <= 0 || videoH <= 0 || viewW <= 0 || viewH <= 0) return

        // TextureView already occupies the whole screen.  Only compensate for
        // the difference in aspect ratio here.  Scaling by raw pixel ratios
        // makes the movie many times larger than the display on some phones.
        val videoAspect = videoW.toFloat() / videoH.toFloat()
        val viewAspect = viewW.toFloat() / viewH.toFloat()
        val scaleX: Float
        val scaleY: Float
        if (videoAspect > viewAspect) {
            scaleX = videoAspect / viewAspect
            scaleY = 1f
        } else {
            scaleX = 1f
            scaleY = viewAspect / videoAspect
        }
        val matrix = Matrix()
        matrix.setScale(scaleX, scaleY, viewW / 2f, viewH / 2f)
        introTexture?.setTransform(matrix)
    }

    override fun onSurfaceTextureSizeChanged(surface: SurfaceTexture, width: Int, height: Int) {
        introPlayer?.let { applyCenterCrop(it.videoWidth, it.videoHeight, width, height) }
    }
    override fun onSurfaceTextureDestroyed(surface: SurfaceTexture): Boolean {
        introPlayer?.release(); introPlayer = null
        return true
    }
    override fun onSurfaceTextureUpdated(surface: SurfaceTexture) = Unit

    private fun routeAfterIntro() {
        introPlayer?.release(); introPlayer = null
        val user = auth.currentUser
        if (user != null && user.isEmailVerified) showHome() else showLogin()
    }

    private fun pageShell(screenTitle: String, subtitle: String): Pair<ScrollView, LinearLayout> {
        val scroll = ScrollView(this).apply {
            isFillViewport = true
            setBackgroundColor(bg)
        }
        val outer = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            gravity = Gravity.CENTER_HORIZONTAL
            setPadding(dp(18), dp(24), dp(18), dp(28))
            background = gradient(Color.rgb(2, 4, 9), Color.rgb(7, 10, 18), radius = 0f)
        }
        scroll.addView(outer, ViewGroup.LayoutParams(-1, -1))
        outer.addView(logo(92))
        outer.addView(title(screenTitle, 28f), LinearLayout.LayoutParams(-1, -2).apply { topMargin = dp(14) })
        outer.addView(sub(subtitle, 12f), LinearLayout.LayoutParams(-1, -2).apply { topMargin = dp(2); bottomMargin = dp(18) })
        return scroll to outer
    }

    private fun showLogin() {
        val (scroll, outer) = pageShell("DMF PANEL", "SECURE ACCESS • MEMBER AREA")
        val c = card()
        outer.addView(c, LinearLayout.LayoutParams(-1, -2))
        c.addView(title("LOGIN", 20f))
        c.addView(sub("Masuk ke akun DMF kamu", 12f), LinearLayout.LayoutParams(-1, -2).apply { bottomMargin = dp(18) })
        val email = field("Email")
        val pass = field("Password", true)
        c.addView(email, LinearLayout.LayoutParams(-1, -2).apply { bottomMargin = dp(12) })
        c.addView(pass, LinearLayout.LayoutParams(-1, -2).apply { bottomMargin = dp(18) })
        c.addView(neonButton("LOGIN") {
            val e = email.text.toString().trim(); val p = pass.text.toString()
            if (e.isBlank() || p.isBlank()) { toast("Isi email dan password dulu"); return@neonButton }
            auth.signInWithEmailAndPassword(e, p).addOnCompleteListener { task ->
                if (!task.isSuccessful) toast(task.exception?.localizedMessage ?: "Login gagal")
                else if (auth.currentUser?.isEmailVerified != true) {
                    auth.signOut(); toast("Verifikasi email dulu, lalu login lagi")
                } else showHome()
            }
        }, LinearLayout.LayoutParams(-1, -2))
        c.addView(neonButton("BUAT AKUN", false) { showRegister() }, LinearLayout.LayoutParams(-1, -2).apply { topMargin = dp(10) })
        outer.addView(sub("Google & Facebook akan muncul setelah provider Firebase diaktifkan.", 11f), LinearLayout.LayoutParams(-1, -2).apply { topMargin = dp(16) })
        setContentView(scroll)
    }

    private fun showRegister() {
        val (scroll, outer) = pageShell("DMF PANEL", "CREATE MEMBER ACCOUNT")
        val c = card(); outer.addView(c, LinearLayout.LayoutParams(-1, -2))
        c.addView(title("REGISTER", 20f))
        c.addView(sub("Daftar lalu verifikasi email kamu", 12f), LinearLayout.LayoutParams(-1, -2).apply { bottomMargin = dp(18) })
        val username = field("Username")
        val email = field("Email aktif")
        val pass = field("Password minimal 6 karakter", true)
        listOf(username, email, pass).forEach { c.addView(it, LinearLayout.LayoutParams(-1, -2).apply { bottomMargin = dp(11) }) }
        c.addView(neonButton("BUAT AKUN") {
            val u = username.text.toString().trim(); val e = email.text.toString().trim(); val p = pass.text.toString()
            if (u.isBlank() || e.isBlank() || p.length < 6) { toast("Isi username, email aktif, dan password minimal 6 karakter"); return@neonButton }
            auth.createUserWithEmailAndPassword(e, p).addOnCompleteListener { task ->
                if (!task.isSuccessful) toast(task.exception?.localizedMessage ?: "Pendaftaran gagal")
                else {
                    prefs.edit().putString("username", u).apply()
                    auth.currentUser?.sendEmailVerification()?.addOnCompleteListener {
                        auth.signOut(); toast("Akun dibuat. Cek email verifikasi, lalu login."); showLogin()
                    }
                }
            }
        }, LinearLayout.LayoutParams(-1, -2).apply { topMargin = dp(5) })
        c.addView(neonButton("KEMBALI KE LOGIN", false) { showLogin() }, LinearLayout.LayoutParams(-1, -2).apply { topMargin = dp(10) })
        setContentView(scroll)
    }

    private fun featureRow(label: String, note: String): LinearLayout {
        val row = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER_VERTICAL
            setPadding(dp(14), dp(11), dp(8), dp(11))
            background = solid(Color.rgb(12, 17, 27), 15, Color.rgb(38, 50, 72))
        }
        val texts = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL }
        texts.addView(TextView(this).apply { text = label; textSize = 14f; setTextColor(Color.WHITE); typeface = Typeface.DEFAULT_BOLD })
        texts.addView(TextView(this).apply { text = note; textSize = 10f; setTextColor(muted) })
        row.addView(texts, LinearLayout.LayoutParams(0, -2, 1f))
        val sw = Switch(this).apply {
            isEnabled = panelActive
            setOnCheckedChangeListener { _, _ -> playSound(R.raw.feature_toggle) }
        }
        row.addView(sw)
        return row
    }

    private fun showHome() {
        val (scroll, outer) = pageShell("DMF PANEL", "CONTROL CENTER")
        val displayName = prefs.getString("username", null) ?: auth.currentUser?.email?.substringBefore("@") ?: "Member"

        val profile = card()
        profile.gravity = Gravity.START
        outer.addView(profile, LinearLayout.LayoutParams(-1, -2))
        profile.addView(TextView(this).apply { text = "WELCOME BACK"; textSize = 10f; setTextColor(blue); typeface = Typeface.DEFAULT_BOLD })
        profile.addView(TextView(this).apply { text = displayName; textSize = 24f; setTextColor(Color.WHITE); typeface = Typeface.DEFAULT_BOLD; setPadding(0, dp(4), 0, 0) })
        profile.addView(TextView(this).apply { text = "FREE MEMBER"; textSize = 11f; setTextColor(Color.rgb(197, 207, 225)); background = solid(Color.rgb(18, 31, 48), 99, Color.rgb(43, 95, 150)); setPadding(dp(10), dp(5), dp(10), dp(5)) }, LinearLayout.LayoutParams(-2, -2).apply { topMargin = dp(8) })

        val panelCard = card(); outer.addView(panelCard, LinearLayout.LayoutParams(-1, -2).apply { topMargin = dp(14) })
        panelCard.addView(title("PANEL STATUS", 18f))
        val status = TextView(this).apply {
            text = if (panelActive) "● ACTIVE" else "● OFFLINE"
            textSize = 13f
            setTextColor(if (panelActive) Color.rgb(79, 226, 146) else Color.rgb(255, 102, 112))
            gravity = Gravity.CENTER
            typeface = Typeface.DEFAULT_BOLD
        }
        panelCard.addView(status, LinearLayout.LayoutParams(-1, -2).apply { topMargin = dp(6); bottomMargin = dp(14) })
        panelCard.addView(neonButton(if (panelActive) "TURN PANEL OFF" else "TURN PANEL ON") {
            panelActive = !panelActive
            playSound(if (panelActive) R.raw.panel_on else R.raw.panel_off)
            showHome()
        }, LinearLayout.LayoutParams(-1, -2))

        panelCard.addView(sub("FEATURE CONTROLS", 11f), LinearLayout.LayoutParams(-1, -2).apply { topMargin = dp(20); bottomMargin = dp(8) })
        val rows = listOf(
            "Visual Preset" to "Pengaturan visual aplikasi DMF",
            "Floating Panel" to "Tampilkan kontrol cepat DMF",
            "Sound Feedback" to "Efek suara tombol dan status",
            "Quick Settings" to "Akses pengaturan aplikasi lebih cepat"
        )
        rows.forEachIndexed { i, pair ->
            panelCard.addView(featureRow(pair.first, pair.second), LinearLayout.LayoutParams(-1, -2).apply { if (i > 0) topMargin = dp(8) })
        }
        outer.addView(sub("Panel ini hanya mengatur fitur aplikasi DMF dan tidak memodifikasi game.", 10f), LinearLayout.LayoutParams(-1, -2).apply { topMargin = dp(12) })
        outer.addView(neonButton("LOGOUT", false) {
            auth.signOut(); prefs.edit().clear().apply(); panelActive = false; showLogin()
        }, LinearLayout.LayoutParams(-1, -2).apply { topMargin = dp(16) })
        setContentView(scroll)
    }
}
