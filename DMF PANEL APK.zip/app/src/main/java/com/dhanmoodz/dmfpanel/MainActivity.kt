package com.dhanmoodz.dmfpanel

import android.app.*
import android.os.*
import android.graphics.Color
import android.media.MediaPlayer
import android.net.Uri
import android.view.*
import android.widget.*
import android.graphics.drawable.GradientDrawable

class MainActivity : Activity() {
    private val prefs by lazy { getSharedPreferences("dmf_session", MODE_PRIVATE) }
    private var panelActive = false

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        showLoading()
    }

    private fun rounded(color:Int, radius:Float=28f, stroke:Int?=null)=GradientDrawable().apply {
        setColor(color); cornerRadius=radius; stroke?.let { setStroke(2,it) }
    }
    private fun base(): LinearLayout = LinearLayout(this).apply {
        orientation=LinearLayout.VERTICAL; gravity=Gravity.CENTER
        setPadding(48,48,48,48); setBackgroundColor(Color.rgb(5,7,11))
    }
    private fun text(s:String, size:Float=18f)=TextView(this).apply {
        text=s; textSize=size; setTextColor(Color.WHITE); gravity=Gravity.CENTER; setPadding(12,12,12,12)
    }
    private fun button(s:String, click:()->Unit)=Button(this).apply {
        text=s; setTextColor(Color.WHITE)
        background=rounded(Color.rgb(15,55,95),24f,Color.rgb(25,139,255))
        setOnClickListener{ click() }
    }
    private fun playSound(resId:Int) {
        val mp = MediaPlayer.create(this,resId) ?: return
        mp.setOnCompletionListener { it.release() }
        mp.start()
    }

    private fun showLoading(){
        val root=base()
        val logo=ImageView(this).apply {
            setImageResource(R.drawable.dmf_logo); adjustViewBounds=true
            layoutParams=LinearLayout.LayoutParams(430,430)
        }
        root.addView(logo); root.addView(text("DMF PANEL",30f)); root.addView(text("LOADING...",14f)); setContentView(root)
        Handler(Looper.getMainLooper()).postDelayed({ showIntro() },1800)
    }

    private fun showIntro(){
        val video=VideoView(this); setContentView(video)
        video.setVideoURI(Uri.parse("android.resource://$packageName/${R.raw.dmf_intro}"))
        video.setOnPreparedListener { it.isLooping=false; video.start() }
        video.setOnCompletionListener { routeAfterIntro() }
        video.setOnErrorListener { _,_,_-> routeAfterIntro(); true }
    }

    private fun routeAfterIntro(){ if(prefs.getBoolean("logged_in",false)) showHome() else showLogin() }

    private fun showLogin(){
        val root=base(); root.addView(text("DMF PANEL",30f)); root.addView(text("LOGIN",20f))
        val user=EditText(this).apply {
            hint="Username"; setTextColor(Color.WHITE); setHintTextColor(Color.GRAY)
            background=rounded(Color.rgb(18,22,30),22f,Color.DKGRAY); setPadding(30,20,30,20)
        }
        val pass=EditText(this).apply {
            hint="Password"; setTextColor(Color.WHITE); setHintTextColor(Color.GRAY); inputType=0x81
            background=rounded(Color.rgb(18,22,30),22f,Color.DKGRAY); setPadding(30,20,30,20)
        }
        root.addView(user, LinearLayout.LayoutParams(-1,-2).apply{setMargins(0,30,0,16)})
        root.addView(pass,LinearLayout.LayoutParams(-1,-2).apply{setMargins(0,0,0,24)})
        root.addView(button("LOGIN") {
            if(user.text.isNotBlank() && pass.text.isNotBlank()){
                prefs.edit().putBoolean("logged_in",true).putString("username",user.text.toString()).apply(); showHome()
            } else Toast.makeText(this,"Isi username dan password dulu",Toast.LENGTH_SHORT).show()
        },LinearLayout.LayoutParams(-1,-2))
        root.addView(text("REGISTER • Google • Facebook\n(disambungkan ke backend di tahap berikutnya)",13f)); setContentView(root)
    }

    private fun featureSwitch(label:String): Switch = Switch(this).apply {
        text=label; textSize=16f; setTextColor(Color.WHITE); setPadding(18,14,18,14)
        isEnabled = panelActive
        setOnCheckedChangeListener { _, _ -> playSound(R.raw.feature_toggle) }
    }

    private fun showHome(){
        val scroll=ScrollView(this)
        val root=base(); scroll.addView(root)
        root.addView(text("DMF PANEL",30f))
        root.addView(text("Selamat datang, ${prefs.getString("username","Member")}",17f))
        root.addView(text("FREE MEMBER",14f))

        val status=text("PANEL NONAKTIF",16f)
        root.addView(status)
        val panelButton=button("AKTIFKAN PANEL") {}
        panelButton.setOnClickListener {
            panelActive=!panelActive
            if(panelActive){
                playSound(R.raw.panel_on); panelButton.text="MATIKAN PANEL"; status.text="PANEL AKTIF"
            } else {
                playSound(R.raw.panel_off); panelButton.text="AKTIFKAN PANEL"; status.text="PANEL NONAKTIF"
            }
            showHome()
        }
        root.addView(panelButton,LinearLayout.LayoutParams(-1,-2).apply{setMargins(0,25,0,18)})

        root.addView(text("FITUR PANEL",18f))
        // UI demo only. Gameplay behavior is connected later to the user's own game source.
        listOf("AIM SILENT", "EPS", "FEATURE 03", "FEATURE 04").forEach { root.addView(featureSwitch(it),LinearLayout.LayoutParams(-1,-2)) }
        root.addView(text("Toggle di build ini baru UI + sound. Mekanik game disambungkan nanti ke game milik sendiri.",12f))
        root.addView(button("LOGOUT") { prefs.edit().clear().apply(); panelActive=false; showLogin() },LinearLayout.LayoutParams(-1,-2).apply{setMargins(0,24,0,0)})
        setContentView(scroll)
    }
}
