package com.dhanmoodz.dmfpanel

import android.app.Activity
import android.graphics.Color
import android.graphics.Typeface
import android.graphics.drawable.GradientDrawable
import android.media.MediaPlayer
import android.net.Uri
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.text.InputType
import android.view.Gravity
import android.view.View
import android.view.ViewGroup
import android.widget.*

class MainActivity : Activity() {
    private val prefs by lazy { getSharedPreferences("dmf_session", MODE_PRIVATE) }
    private var panelActive = false
    private val featureState = linkedMapOf("VISUAL PRESET" to false, "HUD PRESET" to false, "QUICK MENU" to false, "PERFORMANCE MODE" to false)

    private val bg = Color.rgb(5, 7, 12)
    private val card = Color.rgb(13, 18, 27)
    private val blue = Color.rgb(25, 139, 255)
    private val red = Color.rgb(255, 45, 65)

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        window.statusBarColor = bg
        window.navigationBarColor = bg
        showLoading()
    }

    private fun shape(color: Int, radius: Float = 26f, strokeColor: Int? = null, strokeWidth: Int = 2) =
        GradientDrawable().apply {
            setColor(color); cornerRadius = radius
            strokeColor?.let { setStroke(strokeWidth, it) }
        }

    private fun label(value: String, size: Float = 16f, color: Int = Color.WHITE, bold: Boolean = false) =
        TextView(this).apply {
            text = value; textSize = size; setTextColor(color); gravity = Gravity.CENTER
            if (bold) setTypeface(typeface, Typeface.BOLD)
        }

    private fun action(title: String, accent: Int = blue, onClick: () -> Unit) =
        TextView(this).apply {
            text = title; textSize = 15f; setTextColor(Color.WHITE); gravity = Gravity.CENTER
            setTypeface(typeface, Typeface.BOLD); setPadding(24, 20, 24, 20)
            background = shape(Color.rgb(15, 28, 43), 24f, accent)
            isClickable = true; isFocusable = true
            setOnClickListener { playSound(R.raw.feature_toggle); animate().scaleX(.97f).scaleY(.97f).setDuration(70).withEndAction { animate().scaleX(1f).scaleY(1f).setDuration(90).start(); onClick() }.start() }
        }

    private fun page(): LinearLayout = LinearLayout(this).apply {
        orientation = LinearLayout.VERTICAL; gravity = Gravity.CENTER_HORIZONTAL
        setPadding(36, 38, 36, 44); setBackgroundColor(bg)
    }

    private fun playSound(id: Int) {
        MediaPlayer.create(this, id)?.apply {
            setOnCompletionListener { it.release() }; start()
        }
    }

    private fun showLoading() {
        val root = FrameLayout(this).apply { setBackgroundColor(bg) }
        val box = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL; gravity = Gravity.CENTER
            setPadding(44, 44, 44, 44); background = shape(Color.rgb(8, 12, 19), 36f, blue, 3)
        }
        val logo = ImageView(this).apply { setImageResource(R.drawable.dmf_logo); adjustViewBounds = true }
        box.addView(logo, LinearLayout.LayoutParams(360, 360))
        box.addView(label("DMF PANEL", 30f, Color.WHITE, true), LinearLayout.LayoutParams(-1, -2).apply { topMargin = 18 })
        box.addView(label("INITIALIZING", 12f, Color.LTGRAY, true), LinearLayout.LayoutParams(-1, -2).apply { topMargin = 8 })
        val progress = ProgressBar(this, null, android.R.attr.progressBarStyleHorizontal).apply { isIndeterminate = true }
        box.addView(progress, LinearLayout.LayoutParams(-1, 8).apply { topMargin = 28 })
        root.addView(box, FrameLayout.LayoutParams(-1, -2, Gravity.CENTER).apply { leftMargin = 42; rightMargin = 42 })
        setContentView(root)
        Handler(Looper.getMainLooper()).postDelayed({ showIntro() }, 1500)
    }

    private fun showIntro() {
        val root = FrameLayout(this).apply { setBackgroundColor(Color.BLACK) }
        val video = VideoView(this)
        root.addView(video, FrameLayout.LayoutParams(-1, -1, Gravity.CENTER))
        setContentView(root)
        video.setVideoURI(Uri.parse("android.resource://$packageName/${R.raw.dmf_intro}"))
        video.setOnPreparedListener { mp -> mp.isLooping = false; video.start() }
        video.setOnCompletionListener { routeAfterIntro() }
        video.setOnErrorListener { _, _, _ -> routeAfterIntro(); true }
    }

    private fun routeAfterIntro() = if (prefs.getBoolean("logged_in", false)) showHome() else showLogin()

    private fun input(hintText: String, password: Boolean = false) = EditText(this).apply {
        hint = hintText; setTextColor(Color.WHITE); setHintTextColor(Color.rgb(125, 137, 154)); textSize = 15f
        setPadding(28, 20, 28, 20); background = shape(Color.rgb(11, 16, 24), 22f, Color.rgb(42, 55, 72))
        if (password) inputType = InputType.TYPE_CLASS_TEXT or InputType.TYPE_TEXT_VARIATION_PASSWORD
    }

    private fun authHeader(root: LinearLayout, subtitle: String) {
        val logo = ImageView(this).apply { setImageResource(R.drawable.dmf_logo); adjustViewBounds = true }
        root.addView(logo, LinearLayout.LayoutParams(230, 230).apply { topMargin = 20 })
        root.addView(label("DMF PANEL", 29f, Color.WHITE, true), LinearLayout.LayoutParams(-1, -2).apply { topMargin = 12 })
        root.addView(label(subtitle, 13f, Color.rgb(154, 169, 188)), LinearLayout.LayoutParams(-1, -2).apply { topMargin = 5; bottomMargin = 26 })
    }

    private fun showLogin() {
        val scroll = ScrollView(this).apply { setBackgroundColor(bg) }
        val root = page(); scroll.addView(root); authHeader(root, "SECURE MEMBER ACCESS")
        val user = input("Username")
        val pass = input("Password", true)
        root.addView(user, LinearLayout.LayoutParams(-1, -2).apply { bottomMargin = 14 })
        root.addView(pass, LinearLayout.LayoutParams(-1, -2).apply { bottomMargin = 22 })
        root.addView(action("LOGIN") {
            if (user.text.isBlank() || pass.text.isBlank()) Toast.makeText(this, "Isi username dan password dulu", Toast.LENGTH_SHORT).show()
            else { prefs.edit().putBoolean("logged_in", true).putString("username", user.text.toString().trim()).putString("role", "FREE MEMBER").apply(); showHome() }
        }, LinearLayout.LayoutParams(-1, -2))
        root.addView(action("REGISTER", red) { showRegister() }, LinearLayout.LayoutParams(-1, -2).apply { topMargin = 12 })
        root.addView(label("OR CONTINUE WITH", 11f, Color.GRAY, true), LinearLayout.LayoutParams(-1, -2).apply { topMargin = 24; bottomMargin = 12 })
        root.addView(action("GOOGLE", blue) { Toast.makeText(this, "Google disambungkan setelah Firebase config dipasang", Toast.LENGTH_SHORT).show() }, LinearLayout.LayoutParams(-1, -2))
        root.addView(action("FACEBOOK", Color.rgb(70, 100, 180)) { Toast.makeText(this, "Facebook disambungkan setelah konfigurasi auth", Toast.LENGTH_SHORT).show() }, LinearLayout.LayoutParams(-1, -2).apply { topMargin = 10 })
        setContentView(scroll)
    }

    private fun showRegister() {
        val scroll = ScrollView(this).apply { setBackgroundColor(bg) }
        val root = page(); scroll.addView(root); authHeader(root, "CREATE DMF ACCOUNT")
        val username = input("Username")
        val email = input("Email aktif")
        val password = input("Password", true)
        listOf(username, email, password).forEach { root.addView(it, LinearLayout.LayoutParams(-1, -2).apply { bottomMargin = 13 }) }
        root.addView(action("CREATE ACCOUNT") {
            Toast.makeText(this, "Form siap. Verifikasi email diaktifkan saat Firebase Auth disambungkan.", Toast.LENGTH_LONG).show()
        }, LinearLayout.LayoutParams(-1, -2).apply { topMargin = 8 })
        root.addView(action("BACK TO LOGIN", red) { showLogin() }, LinearLayout.LayoutParams(-1, -2).apply { topMargin = 12 })
        setContentView(scroll)
    }

    private fun section(title: String): TextView = label(title, 13f, Color.rgb(154, 169, 188), true).apply { gravity = Gravity.START }

    private fun showHome() {
        val scroll = ScrollView(this).apply { setBackgroundColor(bg) }
        val root = page(); scroll.addView(root)
        val top = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL; gravity = Gravity.CENTER_VERTICAL; setPadding(22, 18, 22, 18); background = shape(card, 26f, Color.rgb(36, 49, 67)) }
        val titles = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL }
        titles.addView(label("DMF PANEL", 23f, Color.WHITE, true).apply { gravity = Gravity.START })
        titles.addView(label("${prefs.getString("username", "Member")} • ${prefs.getString("role", "FREE MEMBER")}", 12f, Color.rgb(157, 177, 201)).apply { gravity = Gravity.START })
        top.addView(titles, LinearLayout.LayoutParams(0, -2, 1f))
        top.addView(action("PANEL", if (panelActive) red else blue) { showPanel() }, LinearLayout.LayoutParams(-2, -2))
        root.addView(top, LinearLayout.LayoutParams(-1, -2))

        root.addView(section("QUICK ACCESS"), LinearLayout.LayoutParams(-1, -2).apply { topMargin = 28; bottomMargin = 10 })
        root.addView(action("OPEN PANEL") { showPanel() }, LinearLayout.LayoutParams(-1, -2))
        root.addView(action("PASANG FILE", red) { Toast.makeText(this, "Akses Pasang File akan mengikuti role server", Toast.LENGTH_SHORT).show() }, LinearLayout.LayoutParams(-1, -2).apply { topMargin = 11 })
        root.addView(action("BUKA GAME") { Toast.makeText(this, "Shortcut game disambungkan setelah package target ditentukan", Toast.LENGTH_SHORT).show() }, LinearLayout.LayoutParams(-1, -2).apply { topMargin = 11 })

        root.addView(section("ACCOUNT"), LinearLayout.LayoutParams(-1, -2).apply { topMargin = 28; bottomMargin = 10 })
        root.addView(action("LOGOUT", red) { prefs.edit().clear().apply(); panelActive = false; showLogin() }, LinearLayout.LayoutParams(-1, -2))
        setContentView(scroll)
    }

    private fun showPanel() {
        val rootFrame = FrameLayout(this).apply { setBackgroundColor(bg) }
        val scroll = ScrollView(this)
        val root = page(); scroll.addView(root)
        root.addView(label("DMF PANEL", 27f, Color.WHITE, true))
        root.addView(label(if (panelActive) "STATUS • ACTIVE" else "STATUS • OFFLINE", 12f, if (panelActive) blue else Color.GRAY, true), LinearLayout.LayoutParams(-1, -2).apply { topMargin = 5; bottomMargin = 22 })

        val master = action(if (panelActive) "TURN PANEL OFF" else "TURN PANEL ON", if (panelActive) red else blue) {
            panelActive = !panelActive; playSound(if (panelActive) R.raw.panel_on else R.raw.panel_off); showPanel()
        }
        root.addView(master, LinearLayout.LayoutParams(-1, -2))
        root.addView(section("PANEL FEATURES"), LinearLayout.LayoutParams(-1, -2).apply { topMargin = 26; bottomMargin = 10 })

        featureState.keys.toList().forEach { name ->
            val row = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL; gravity = Gravity.CENTER_VERTICAL; setPadding(22, 13, 12, 13); background = shape(card, 22f, Color.rgb(35, 48, 65)) }
            row.addView(label(name, 14f, Color.WHITE, true).apply { gravity = Gravity.START }, LinearLayout.LayoutParams(0, -2, 1f))
            val toggle = Switch(this).apply {
                isEnabled = panelActive; isChecked = featureState[name] == true
                setOnCheckedChangeListener { _, checked -> featureState[name] = checked; playSound(R.raw.feature_toggle) }
            }
            row.addView(toggle)
            root.addView(row, LinearLayout.LayoutParams(-1, -2).apply { bottomMargin = 10 })
        }
        root.addView(action("APPLY PRESET") { Toast.makeText(this, "Preset DMF diterapkan", Toast.LENGTH_SHORT).show() }, LinearLayout.LayoutParams(-1, -2).apply { topMargin = 8 })
        root.addView(action("BACK HOME", red) { showHome() }, LinearLayout.LayoutParams(-1, -2).apply { topMargin = 11 })
        rootFrame.addView(scroll, FrameLayout.LayoutParams(-1, -1))

        // In-app floating button: lightweight and does not request draw-over-other-apps permission.
        val floating = TextView(this).apply {
            text = "DMF"; setTextColor(Color.WHITE); textSize = 12f; gravity = Gravity.CENTER; setTypeface(typeface, Typeface.BOLD)
            background = shape(Color.rgb(12, 31, 52), 60f, if (panelActive) blue else red, 3)
            setOnClickListener { visibility = if (scroll.visibility == View.VISIBLE) View.INVISIBLE else View.VISIBLE }
        }
        rootFrame.addView(floating, FrameLayout.LayoutParams(116, 116, Gravity.END or Gravity.CENTER_VERTICAL).apply { rightMargin = 18 })
        setContentView(rootFrame)
    }

    override fun onBackPressed() {
        showHome()
    }
}
