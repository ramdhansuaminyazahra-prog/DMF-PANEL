package com.dhanmoodz.app

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp

private val Bg = Color(0xFF0B0B0F)
private val Card = Color(0xFF15151B)
private val Accent = Color(0xFFFFC107)

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContent { DhanMoodzApp() }
    }
}

@Composable
fun DhanMoodzApp() {
    MaterialTheme(
        colorScheme = darkColorScheme(
            background = Bg,
            surface = Card,
            primary = Accent,
            onPrimary = Color.Black
        )
    ) {
        Surface(modifier = Modifier.fillMaxSize(), color = Bg) {
            HomeScreen()
        }
    }
}

@Composable
fun HomeScreen() {
    var selected by remember { mutableStateOf(0) }
    val tabs = listOf("Home", "About", "Contact")

    Column(Modifier.fillMaxSize()) {
        Row(
            Modifier.fillMaxWidth().padding(horizontal = 20.dp, vertical = 18.dp),
            horizontalArrangement = Arrangement.SpaceBetween,
            verticalAlignment = Alignment.CenterVertically
        ) {
            Text("DHAN MOODZ", fontSize = 22.sp, fontWeight = FontWeight.Black)
            Text("OFFICIAL", color = Accent, fontSize = 12.sp, fontWeight = FontWeight.Bold)
        }

        Box(Modifier.weight(1f).fillMaxWidth()) {
            when (selected) {
                0 -> HomeContent()
                1 -> AboutContent()
                else -> ContactContent()
            }
        }

        NavigationBar(containerColor = Card) {
            tabs.forEachIndexed { i, label ->
                NavigationBarItem(
                    selected = selected == i,
                    onClick = { selected = i },
                    icon = {},
                    label = { Text(label) }
                )
            }
        }
    }
}

@Composable
fun HomeContent() {
    Column(
        Modifier.fillMaxSize().verticalScroll(rememberScrollState()).padding(20.dp)
    ) {
        Text("Dhan Moodz", fontSize = 42.sp, fontWeight = FontWeight.Black)
        Text("Official mobile experience", color = Color.LightGray, fontSize = 17.sp)
        Spacer(Modifier.height(24.dp))
        Card(colors = CardDefaults.cardColors(containerColor = Card)) {
            Column(Modifier.padding(22.dp)) {
                Text("Welcome", fontSize = 24.sp, fontWeight = FontWeight.Bold)
                Spacer(Modifier.height(10.dp))
                Text(
                    "A native Android rebuild of the Dhan Moodz Official website. " +
                    "The app is structured so its UI and features can be implemented independently from the website.",
                    color = Color.LightGray, lineHeight = 22.sp
                )
                Spacer(Modifier.height(18.dp))
                Button(onClick = {}) { Text("Get Started") }
            }
        }
        Spacer(Modifier.height(18.dp))
        Text("Features", fontSize = 24.sp, fontWeight = FontWeight.Bold)
        Spacer(Modifier.height(10.dp))
        FeatureCard("Native UI", "Jetpack Compose components, not a WebView.")
        FeatureCard("Offline-ready", "Architecture can keep local state without requiring the website.")
        FeatureCard("Expandable", "Add authentication, API, notifications and other native features.")
    }
}

@Composable
fun FeatureCard(title: String, body: String) {
    Card(
        Modifier.fillMaxWidth().padding(vertical = 5.dp),
        colors = CardDefaults.cardColors(containerColor = Card)
    ) {
        Column(Modifier.padding(18.dp)) {
            Text(title, fontWeight = FontWeight.Bold, fontSize = 18.sp)
            Spacer(Modifier.height(5.dp))
            Text(body, color = Color.LightGray)
        }
    }
}

@Composable
fun AboutContent() {
    Column(Modifier.fillMaxSize().verticalScroll(rememberScrollState()).padding(20.dp)) {
        Text("About", fontSize = 34.sp, fontWeight = FontWeight.Black)
        Spacer(Modifier.height(14.dp))
        Text(
            "This project is a native Android foundation for Dhan Moodz Official. " +
            "The public website was inspected as the reference point; its exact visual sections " +
            "and interactive behavior can be mapped into Compose screens as the source details become available.",
            color = Color.LightGray, lineHeight = 23.sp
        )
    }
}

@Composable
fun ContactContent() {
    Column(Modifier.fillMaxSize().padding(20.dp)) {
        Text("Contact", fontSize = 34.sp, fontWeight = FontWeight.Black)
        Spacer(Modifier.height(14.dp))
        OutlinedTextField(value = "", onValueChange = {}, label = { Text("Name") }, modifier = Modifier.fillMaxWidth())
        Spacer(Modifier.height(10.dp))
        OutlinedTextField(value = "", onValueChange = {}, label = { Text("Message") }, modifier = Modifier.fillMaxWidth().height(140.dp))
        Spacer(Modifier.height(14.dp))
        Button(onClick = {}, modifier = Modifier.fillMaxWidth()) { Text("Send") }
    }
}
