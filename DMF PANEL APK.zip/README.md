# Dhan Moodz Native Android

Native Android/Jetpack Compose starter project for rebuilding Dhan Moodz Official.

Reference website:
https://dhan-moodz-official.vercel.app/

Important: this project does NOT use WebView. The UI is native Jetpack Compose.

## Build
Open this folder in Android Studio, let Gradle sync, then:
Build > Build APK(s)

CLI:
./gradlew assembleDebug

APK:
app/build/outputs/apk/debug/app-debug.apk

## Next implementation step
Map every section/interaction from the website into native Compose screens and connect any required API/backend.
